﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JackAnalyzer
{
    enum TokenType
    {
        keyword,
        identifier,
        symbol,
        integerConstant,
        stringConstant
    }
}

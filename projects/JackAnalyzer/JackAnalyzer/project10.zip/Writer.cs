﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Security;
using System.Linq;

namespace JackAnalyzer
{
    class Writer
    {
        private Queue<KeyValuePair<TokenType, string>> tokenQueue;
        public Writer(string path, List<KeyValuePair<TokenType, string>> tokens)
        {
            string filename = Path.ChangeExtension(path, ".xml");
            tokenQueue = new Queue<KeyValuePair<TokenType, string>>(tokens);
            using (StreamWriter file = new StreamWriter(filename))
            {
                var token = tokenQueue.Peek();

                if (token.Key == TokenType.keyword)
                {
                    string keyword = token.Value;
                    if (keyword == "class")
                    {
                        string[] classLines = CompileClass();
                        foreach (string line in classLines)
                        {
                            file.WriteLine(line);
                        }
                    }
                }
            }
        }

        // 'class' className '{' classVarDec* subroutineDec* '}'
        private string[] CompileClass()
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(0, "class"));

            output.AddRange(PutNTokens(1, 3));

            // classVarDec*
            var token = tokenQueue.Peek();
            while (token.Value == "static" || token.Value == "field")
            {
                output.AddRange(CompileClassVarDec(1));
                token = tokenQueue.Peek();
            }

            // subroutineDec*
            token = tokenQueue.Peek();
            while (token.Value == "function" || token.Value == "constructor" || token.Value == "method" || token.Value == "void")
            {
                output.AddRange(CompileSubroutine(1));
                token = tokenQueue.Peek();
            }

            // } 
            output.AddRange(PutNTokens(1, 1));

            output.Add(PutCloseTag(0, "class"));

            return output.ToArray();
        }

        // ('static' | 'field') type varName (',' varName)* ';'
        private string[] CompileClassVarDec(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "classVarDec"));

            output.AddRange(PutNTokens(indent + 1, 3));

            var token = tokenQueue.Peek();
            while (token.Value == ",")
            {
                output.AddRange(PutNTokens(indent + 1, 2));
                token = tokenQueue.Peek();
            }

            output.AddRange(PutNTokens(indent + 1, 1));

            output.Add(PutCloseTag(indent, "classVarDec"));

            return output.ToArray();
        }

        // ('constructor' | 'function' | 'method')
        // ('void' | type) subroutineName '(' parameterList ')' subroutineBody
        private string[] CompileSubroutine(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "subroutineDec"));

            output.AddRange(PutNTokens(indent + 1, 4));

            // parameterList
            output.AddRange(CompileParameterList(indent + 1));

            output.AddRange(PutNTokens(indent + 1, 1));

            output.AddRange(CompileSubroutineBody(indent + 1));

            output.Add(PutCloseTag(indent, "subroutineDec"));

            return output.ToArray();
        }

        // '{' varDec* statements '}'
        private string[] CompileSubroutineBody(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "subroutineBody"));

            output.AddRange(PutNTokens(indent + 1, 1));

            // varDec*
            var token = tokenQueue.Peek();
            while (token.Value == "var")
            {
                output.AddRange(CompileVarDec(indent + 1));
                token = tokenQueue.Peek();
            }

            output.AddRange(CompileStatements(indent + 1));

            // } 
            output.AddRange(PutNTokens(indent + 1, 1));

            output.Add(PutCloseTag(indent, "subroutineBody"));

            return output.ToArray();
        }

        // statement*
        private string[] CompileStatements(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "statements"));

            bool finished = false;

            var token = tokenQueue.Peek();

            while (!finished)
            {
                switch (token.Value)
                {
                    case "do":
                        output.AddRange(CompileDoStatement(indent + 1));
                        break;
                    case "let":
                        output.AddRange(CompileLetStatement(indent + 1));
                        break;
                    case "while":
                        output.AddRange(CompileWhileStatement(indent + 1));
                        break;
                    case "return":
                        output.AddRange(CompileReturnStatement(indent + 1));
                        break;
                    case "if":
                        output.AddRange(CompileIfStatement(indent + 1));
                        break;
                    default:
                        finished = true;
                        break;
                }
                token = tokenQueue.Peek();
            }


            output.Add(PutCloseTag(indent, "statements"));

            return output.ToArray();
        }

        // 'do' subroutineCall ';'
        private string[] CompileDoStatement(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "doStatement"));

            output.AddRange(PutNTokens(indent + 1, 1));

            var queueEnumerator = tokenQueue.GetEnumerator();
            queueEnumerator.MoveNext();
            queueEnumerator.MoveNext();
            var nextToken = queueEnumerator.Current;

            // subroutineName '(' expressionList ')' | (className |
            // varName) '.' subroutineName '(' expressionList ')'
            if (nextToken.Value == ".")
            {

                output.AddRange(PutNTokens(indent + 1, 4));
                output.AddRange(CompileExpressionList(indent + 1));
                output.AddRange(PutNTokens(indent + 1, 1));
            }
            else if (nextToken.Value == "(")
            {
                output.AddRange(PutNTokens(indent + 1, 2));
                output.AddRange(CompileExpressionList(indent + 1));
                output.AddRange(PutNTokens(indent + 1, 1));
            }

            // ;
            output.AddRange(PutNTokens(indent + 1, 1));

            output.Add(PutCloseTag(indent, "doStatement"));

            return output.ToArray();
        }

        // 'let' varName ('[' expression ']')? '=' expression ';'
        private string[] CompileLetStatement(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "letStatement"));

            output.AddRange(PutNTokens(indent + 1, 2));

            var token = tokenQueue.Peek();
            if (token.Value == "[")
            {
                output.AddRange(PutNTokens(indent + 1, 1));
                output.AddRange(CompileExpression(indent + 1));
                output.AddRange(PutNTokens(indent + 1, 1));
            }

            output.AddRange(PutNTokens(indent + 1, 1));
            output.AddRange(CompileExpression(indent + 1));
            output.AddRange(PutNTokens(indent + 1, 1));

            output.Add(PutCloseTag(indent, "letStatement"));

            return output.ToArray();
        }

        // 'while' '(' expression ')' '{' statements '}'
        private string[] CompileWhileStatement(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "whileStatement"));

            output.AddRange(PutNTokens(indent + 1, 2));
            output.AddRange(CompileExpression(indent + 1));
            output.AddRange(PutNTokens(indent + 1, 2));
            output.AddRange(CompileStatements(indent + 1));
            output.AddRange(PutNTokens(indent + 1, 1));

            output.Add(PutCloseTag(indent, "whileStatement"));

            return output.ToArray();
        }

        // 'return' expression? ';'
        private string[] CompileReturnStatement(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "returnStatement"));

            output.AddRange(PutNTokens(indent + 1, 1));

            var token = tokenQueue.Peek();
            if (token.Value != ";")
            {
                output.AddRange(CompileExpression(indent + 1));
            }

            output.AddRange(PutNTokens(indent + 1, 1));

            output.Add(PutCloseTag(indent, "returnStatement"));

            return output.ToArray();
        }

        // 'if' '(' expression ')' '{' statements '}' ('else' '{' statements '}')?
        private string[] CompileIfStatement(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "ifStatement"));

            output.AddRange(PutNTokens(indent + 1, 2));
            output.AddRange(CompileExpression(indent + 1));
            output.AddRange(PutNTokens(indent + 1, 2));
            output.AddRange(CompileStatements(indent + 1));
            output.AddRange(PutNTokens(indent + 1, 1));

            var token = tokenQueue.Peek();
            if (token.Value == "else")
            {
                output.AddRange(PutNTokens(indent + 1, 2));
                output.AddRange(CompileStatements(indent + 1));
                output.AddRange(PutNTokens(indent + 1, 1));
            }

            output.Add(PutCloseTag(indent, "ifStatement"));

            return output.ToArray();
        }

        // 'var' type varName (',' varName)* ';'
        private string[] CompileVarDec(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "varDec"));

            output.AddRange(PutNTokens(indent + 1, 3));

            var token = tokenQueue.Peek();
            while (token.Value == ",")
            {
                output.AddRange(PutNTokens(indent + 1, 2));
                token = tokenQueue.Peek();
            }

            output.AddRange(PutNTokens(indent + 1, 1));

            output.Add(PutCloseTag(indent, "varDec"));

            return output.ToArray();
        }

        // ((type varName) (',' type varName)*)?
        private string[] CompileParameterList(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "parameterList"));

            var token = tokenQueue.Peek();
            if (token.Key == TokenType.keyword)
            {
                output.AddRange(PutNTokens(indent + 1, 2));

                token = tokenQueue.Peek();
                while (token.Value == ",")
                {
                    output.AddRange(PutNTokens(indent + 1, 3));
                    token = tokenQueue.Peek();
                }
            }

            output.Add(PutCloseTag(indent, "parameterList"));

            return output.ToArray();
        }

        // term (op term)*
        private string[] CompileExpression(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "expression"));

            output.AddRange(CompileTerm(indent + 1));

            var token = tokenQueue.Peek();
            while (Constants.op.Contains(token.Value[0]))
            {
                output.AddRange(PutNTokens(indent + 1, 1));
                output.AddRange(CompileTerm(indent + 1));
                token = tokenQueue.Peek();
            }

            output.Add(PutCloseTag(indent, "expression"));

            return output.ToArray();
        }

        // integerConstant | stringConstant | keywordConstant |
        // varName | varName '[' expression ']' | subroutineCall |
        // '(' expression ')' | unaryOp term
        private string[] CompileTerm(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "term"));

            var token = tokenQueue.Peek();

            var queueEnumerator = tokenQueue.GetEnumerator();

            queueEnumerator.MoveNext();
            queueEnumerator.MoveNext();

            var nextToken = queueEnumerator.Current;

            if (Constants.unaryOp.Contains(token.Value[0]))
            {
                output.AddRange(PutNTokens(indent + 1, 1));
                output.AddRange(CompileTerm(indent + 1));
            }
            else if (token.Key == TokenType.identifier && nextToken.Value == ".")
            {
                // subroutineName '(' expressionList ')' | (className |
                // varName) '.' subroutineName '(' expressionList ')'

                output.AddRange(PutNTokens(indent + 1, 4));
                output.AddRange(CompileExpressionList(indent + 1));
                output.AddRange(PutNTokens(indent + 1, 1));
            }
            else if (token.Key == TokenType.identifier && nextToken.Value == "(")
            {
                output.AddRange(PutNTokens(indent + 1, 2));
                output.AddRange(CompileExpressionList(indent + 1));
                output.AddRange(PutNTokens(indent + 1, 1));
            }
            else if (nextToken.Value == "[")
            {
                output.AddRange(PutNTokens(indent + 1, 2));
                output.AddRange(CompileExpression(indent + 1));
                output.AddRange(PutNTokens(indent + 1, 1));
            }
            else if (token.Value == "(")
            {
                output.AddRange(PutNTokens(indent + 1, 1));
                output.AddRange(CompileExpression(indent + 1));
                output.AddRange(PutNTokens(indent + 1, 1));
            }
            else
            {
                output.AddRange(PutNTokens(indent + 1, 1));
            }

            output.Add(PutCloseTag(indent, "term"));

            return output.ToArray();
        }

        // (expression (',' expression)* )?
        private string[] CompileExpressionList(int indent)
        {
            List<string> output = new List<string>();

            output.Add(PutOpenTag(indent, "expressionList"));

            var token = tokenQueue.Peek();
            if (token.Value != ")")
            {
                output.AddRange(CompileExpression(indent + 1));

                token = tokenQueue.Peek();
                while (token.Value == ",")
                {
                    output.AddRange(PutNTokens(indent + 1, 1));
                    output.AddRange(CompileExpression(indent + 1));
                    token = tokenQueue.Peek();
                }
            }

            output.Add(PutCloseTag(indent, "expressionList"));

            return output.ToArray();
        }


        private string[] PutNTokens(int indent, int n)
        {
            List<string> output = new List<string>();

            for (int i = 0; i < n; i++)
            {
                output.Add(PutToken(indent));
            }

            return output.ToArray();
        }

        private string PutToken(int indent)
        {
            var token = tokenQueue.Dequeue();
            return PutLineTag(indent, Enum.GetName(typeof(TokenType), token.Key), token.Value);
        }

        private string PutOpenTag(int indent, string name)
        {
            return new string(' ', indent * Constants.indentLevel) + '<' + name + '>';
        }

        private string PutCloseTag(int indent, string name)
        {
            return new string(' ', indent * Constants.indentLevel) + "</" + name + '>';
        }

        private string PutLineTag(int indent, string name, string value)
        {
            return new string(' ', indent * Constants.indentLevel) + '<' + name + "> " + SecurityElement.Escape(value) + " </" + name + '>';
        }
    }
}

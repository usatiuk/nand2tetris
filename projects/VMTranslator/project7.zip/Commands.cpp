#include "Commands.h"

std::unordered_map<std::string, CommandType> CommandTypeDict = {
    {"", CommandType::Empty},
    {"push", CommandType::Push},
    {"pop", CommandType::Pop},
    {"add", CommandType::Add},
    {"sub", CommandType::Sub},
    {"neg", CommandType::Neg},
    {"eq", CommandType::Eq},
    {"gt", CommandType::Gt},
    {"lt", CommandType::Lt},
    {"and", CommandType::And},
    {"or", CommandType::Or},
    {"not", CommandType::Not},
};

std::unordered_map<CommandType, std::string> TypeCommandDict = []() {
    std::unordered_map<CommandType, std::string> rev;
    for(auto &cmd : CommandTypeDict) {
        rev[cmd.second] = cmd.first;
    }
    return rev;
}
();

std::ostream& operator<< ( std::ostream &os, const Command &cmd ) {
    os << TypeCommandDict[cmd.type] << " " << cmd.arg1 << " " << cmd.arg2;
    return os;
}

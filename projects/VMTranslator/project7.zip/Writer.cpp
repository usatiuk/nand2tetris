#include "Writer.h"

Writer::Writer ( std::string file ) {
    int slashPos = file.rfind ( "/" );
    filename = file.substr ( slashPos + 1, file.length() );
    int dotPos = filename.rfind ( "." );
    classname = filename.substr ( 0, dotPos );

    outfile.open ( file, std::ios::out | std::ios::trunc );
    if ( !outfile.is_open() ) {
        throw std::invalid_argument ( "Can't open output file" );
    }
}


void Writer::close() {
    outfile.close();
}

void Writer::writeCmd ( Command cmd ) {
    outfile << "// " << cmd << std::endl;
    switch ( cmd.type ) {
    case CommandType::Empty:
        break;
    case CommandType::Add:
    case CommandType::Sub:
    case CommandType::Neg:
    case CommandType::Eq:
    case CommandType::Gt:
    case CommandType::Lt:
    case CommandType::And:
    case CommandType::Or:
    case CommandType::Not:
        writeArith ( cmd );
        break;
    case CommandType::Push:
    case CommandType::Pop:
        writePushPop ( cmd );
        break;
    }
    return;
}

void Writer::writeArith ( Command cmd ) {
    static int arithCounter = 0;
    if ( cmd.type != CommandType::Neg && cmd.type != CommandType::Not  ) {
        outfile << "@SP" << std::endl;
        outfile << "M=M-1" << std::endl;
        outfile << "A=M" << std::endl;
        outfile << "D=M" << std::endl;
        outfile << "@R13" << std::endl;
        outfile << "M=D" << std::endl;
        outfile << "@SP" << std::endl;
        outfile << "M=M-1" << std::endl;
        outfile << "A=M" << std::endl;
        outfile << "D=M" << std::endl;
        outfile << "@R14" << std::endl;
        outfile << "M=D" << std::endl;
    }

    switch ( cmd.type ) {
    case CommandType::Add:
        outfile << "@R13" << std::endl;
        outfile << "D=M" << std::endl;
        outfile << "@R14" << std::endl;
        outfile << "D=M+D" << std::endl;
        break;
    case CommandType::Sub:
        outfile << "@R13" << std::endl;
        outfile << "D=M" << std::endl;
        outfile << "@R14" << std::endl;
        outfile << "D=M-D" << std::endl;
        break;
    case CommandType::Neg:
        outfile << "@SP" << std::endl;
        outfile << "M=M-1" << std::endl;
        outfile << "A=M" << std::endl;
        outfile << "D=-M" << std::endl;
        break;
            case CommandType::Not:
        outfile << "@SP" << std::endl;
        outfile << "M=M-1" << std::endl;
        outfile << "A=M" << std::endl;
        outfile << "D=!M" << std::endl;
        break;

    case CommandType::Eq:
        outfile << "@R13" << std::endl;
        outfile << "D=M" << std::endl;
        outfile << "@R14" << std::endl;
        outfile << "D=M-D" << std::endl;
        outfile << "@T" << arithCounter << std::endl;
        outfile << "D;JEQ" << std::endl;
        outfile << "@END" << arithCounter << std::endl;
        outfile << "D=0;JMP" << std::endl;
        outfile << "(T" << arithCounter << ")" << std::endl;
        outfile << "D=-1" << std::endl;
        break;
            case CommandType::Gt:
        outfile << "@R13" << std::endl;
        outfile << "D=M" << std::endl;
        outfile << "@R14" << std::endl;
        outfile << "D=M-D" << std::endl;
        outfile << "@T" << arithCounter << std::endl;
        outfile << "D;JGT" << std::endl;
        outfile << "@END" << arithCounter << std::endl;
        outfile << "D=0;JMP" << std::endl;
        outfile << "(T" << arithCounter << ")" << std::endl;
        outfile << "D=-1" << std::endl;
        break;
    case CommandType::Lt:
        outfile << "@R13" << std::endl;
        outfile << "D=M" << std::endl;
        outfile << "@R14" << std::endl;
        outfile << "D=M-D" << std::endl;
        outfile << "@T" << arithCounter << std::endl;
        outfile << "D;JLT" << std::endl;
        outfile << "@END" << arithCounter << std::endl;
        outfile << "D=0;JMP" << std::endl;
        outfile << "(T" << arithCounter << ")" << std::endl;
        outfile << "D=-1" << std::endl;
        break;
    case CommandType::And:
        outfile << "@R13" << std::endl;
        outfile << "D=M" << std::endl;
        outfile << "@R14" << std::endl;
        outfile << "D=M&D" << std::endl;
        break;
    case CommandType::Or:
        outfile << "@R13" << std::endl;
        outfile << "D=M" << std::endl;
        outfile << "@R14" << std::endl;
        outfile << "D=M|D" << std::endl;
        break;

    }
    outfile << "(END" << arithCounter << ")" << std::endl;
    outfile << "@SP" << std::endl;
    outfile << "A=M" << std::endl;
    outfile << "M=D" << std::endl;
    outfile << "@SP" << std::endl;
    outfile << "M=M+1" << std::endl;
    arithCounter++;
    return;
}

void Writer::writePushPop ( Command cmd ) {
    switch ( cmd.type ) {
    case CommandType::Push:
        if ( cmd.arg1 == "constant" ) {
            outfile << "@" <<cmd.arg2 <<std::endl;
            outfile << "D=A" << std::endl;
        } else if ( cmd.arg1 == "local" ) {
            outfile << "@" <<cmd.arg2 <<std::endl;
            outfile << "D=A" << std::endl;
            outfile << "@LCL" <<std::endl;
            outfile << "A=M+D" << std::endl;
            outfile << "D=M" << std::endl;
        } else if ( cmd.arg1 == "argument" ) {
            outfile << "@" <<cmd.arg2 <<std::endl;
            outfile << "D=A" << std::endl;
            outfile << "@ARG" <<std::endl;
            outfile << "A=M+D" << std::endl;
            outfile << "D=M" << std::endl;
        } else if ( cmd.arg1 == "this" ) {
            outfile << "@" <<cmd.arg2 <<std::endl;
            outfile << "D=A" << std::endl;
            outfile << "@THIS" <<std::endl;
            outfile << "A=M+D" << std::endl;
            outfile << "D=M" << std::endl;
        } else if ( cmd.arg1 == "that" ) {
            outfile << "@" <<cmd.arg2 <<std::endl;
            outfile << "D=A" << std::endl;
            outfile << "@THAT" <<std::endl;
            outfile << "A=M+D" << std::endl;
            outfile << "D=M" << std::endl;
        } else if ( cmd.arg1 == "static" ) {
            outfile << "@" << classname << "." << cmd.arg2 <<std::endl;
            outfile << "D=M" << std::endl;
        } else if ( cmd.arg1 =="temp" ) {
            outfile << "@R" << 5 + cmd.arg2 <<std::endl;
            outfile << "D=M" << std::endl;
        } else if ( cmd.arg1 == "pointer" ) {
            if ( cmd.arg2 == 0 ) {
                outfile << "@THIS" <<std::endl;
            } else if ( cmd.arg2 == 1 ) {
                outfile << "@THAT" <<std::endl;
            }
            outfile << "D=M" << std::endl;
        }

        outfile << "@SP" << std::endl;
        outfile << "A=M" << std::endl;
        outfile << "M=D" << std::endl;
        outfile << "@SP" << std::endl;
        outfile << "M=M+1" << std::endl;
        break;
    case CommandType::Pop:
        outfile << "@SP" << std::endl;
        outfile << "M=M-1" << std::endl;
        outfile << "A=M" << std::endl;
        outfile << "D=M" << std::endl;
        outfile << "@R13" << std::endl;
        outfile << "M=D" << std::endl;


        if ( cmd.arg1 == "local" ) {
            outfile << "@" <<cmd.arg2 <<std::endl;
            outfile << "D=A" << std::endl;
            outfile << "@LCL" <<std::endl;
            outfile << "D=M+D" << std::endl;
            outfile << "@R14" << std::endl;
            outfile << "M=D" << std::endl;
            outfile << "@R13" << std::endl;
            outfile << "D=M" << std::endl;
            outfile << "@R14" << std::endl;
            outfile << "A=M" << std::endl;
            outfile << "M=D" << std::endl;
        } else if ( cmd.arg1 == "argument" ) {
            outfile << "@" <<cmd.arg2 <<std::endl;
            outfile << "D=A" << std::endl;
            outfile << "@ARG" <<std::endl;
            outfile << "D=M+D" << std::endl;
            outfile << "@R14" << std::endl;
            outfile << "M=D" << std::endl;
            outfile << "@R13" << std::endl;
            outfile << "D=M" << std::endl;
            outfile << "@R14" << std::endl;
            outfile << "A=M" << std::endl;
            outfile << "M=D" << std::endl;
        } else if ( cmd.arg1 == "this" ) {
            outfile << "@" <<cmd.arg2 <<std::endl;
            outfile << "D=A" << std::endl;
            outfile << "@THIS" <<std::endl;
            outfile << "D=M+D" << std::endl;
            outfile << "@R14" << std::endl;
            outfile << "M=D" << std::endl;
            outfile << "@R13" << std::endl;
            outfile << "D=M" << std::endl;
            outfile << "@R14" << std::endl;
            outfile << "A=M" << std::endl;
            outfile << "M=D" << std::endl;
        } else if ( cmd.arg1 == "that" ) {
            outfile << "@" <<cmd.arg2 <<std::endl;
            outfile << "D=A" << std::endl;
            outfile << "@THAT" <<std::endl;
            outfile << "D=M+D" << std::endl;
            outfile << "@R14" << std::endl;
            outfile << "M=D" << std::endl;
            outfile << "@R13" << std::endl;
            outfile << "D=M" << std::endl;
            outfile << "@R14" << std::endl;
            outfile << "A=M" << std::endl;
            outfile << "M=D" << std::endl;
        } else if ( cmd.arg1 == "static" ) {
            outfile << "@" << classname << "." << cmd.arg2 <<std::endl;
            outfile << "M=D" << std::endl;
        } else if ( cmd.arg1 =="temp" ) {
            outfile << "@R" << 5 + cmd.arg2 <<std::endl;
            outfile << "M=D" << std::endl;
        } else if ( cmd.arg1 == "pointer" ) {
            if ( cmd.arg2 == 0 ) {
                outfile << "@THIS" <<std::endl;
            } else if ( cmd.arg2 == 1 ) {
                outfile << "@THAT" <<std::endl;
            }
            outfile << "M=D" << std::endl;
        }
        break;

        break;
    }
    return;
}




#ifndef WRITER_H
#define WRITER_H

#include <fstream>
#include <string>
#include <exception>
#include <iostream>

#include "Commands.h"
class Writer {
    private:
    std::ofstream outfile;
    void writeArith(Command cmd);
    void writePushPop(Command cmd);
    std::string filename;
    std::string classname;

    public:
    Writer ( std::string file );
    void close();
    void writeCmd(Command cmd);

};

#endif // WRITER_H

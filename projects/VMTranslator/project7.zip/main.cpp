#include <iostream>
#include <exception>
#include <string>

#include "Parser.h"
#include "Writer.h"

Parser *parser;
Writer *writer;

int main ( int argc, char **argv ) {
    if ( argc != 2 ) {
        std::cout << "Not enough arguments" << std::endl;
        return 1;
    }

    std::string infile ( argv[1] );

    try {
        parser = new Parser ( infile );
    } catch ( const std::invalid_argument& e ) {
        std::cout << e.what() << std::endl;
        return 2;
    }

    std::string outfile;
    int dotPos = infile.rfind ( "." );
    outfile = infile.substr ( 0, dotPos );
    outfile += ".asm";

    try {
        writer = new Writer ( outfile );
    } catch ( const std::invalid_argument& e ) {
        std::cout << e.what() << std::endl;
        return 3;
    }


    while ( parser->more() ) {
        Command cmd;
        cmd = parser->next();
        writer->writeCmd(cmd);
    }
    
    parser->close();
    writer->close();
    
    return 0;
}
